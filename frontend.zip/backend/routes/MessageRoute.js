const express = require('express');
const router = express.Router();
const Message = require('./../controllers/MessageController.js');


module.exports = router;