const express = require('express');
const router = express.Router();
const Appointment = require('./../controllers/AppointmentController.js');


module.exports = router;