const TOKEN_SECRET = "uqFdqVe6A1#z!@KtPqR&87s";
module.exports = { TOKEN_SECRET };
